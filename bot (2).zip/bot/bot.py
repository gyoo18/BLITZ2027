from game_message import *
from strategy import Strategy


class Bot:
    def __init__(self):
        print("Initializing your super mega duper bot")
        self.strategy = Strategy()

    def get_next_move(self, game_message: TeamGameState) -> list[Action]:
        # Affiche le score tous les 100 tours, et au dernier tour
        if game_message.tick % 100 == 0 or game_message.tick == game_message.constants.maxTicks:
            print(f"*** Tour {game_message.tick} - SCORE : {game_message.score} ***")
        # Une seule action est appliquée par tour (actions[0]).
        return self.strategy.decide(game_message)
