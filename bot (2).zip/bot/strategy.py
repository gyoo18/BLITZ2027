"""Stratégie du bot Blitz 2027 - défi de l'extinction.

Idée principale : les dinosaures voient la météorite arriver et fuient.
On vise donc les endroits où ils NE PEUVENT PAS sortir de la zone d'impact
avant qu'elle tombe (zone en losange, distance de Manhattan <= rayon).
On privilégie les jeunes dinosaures (plus de points) et les tirs qui
en tuent plusieurs à la fois (bonus multi-kill).
"""

import time
from sim import World, Sim

from game_message import (
    LaunchMeteorAction,
    TeamGameState,
    TriggerVolcanoAction,
    WorldPosition,
)

TIME_BUDGET = 0.08
import os as _os
SIMON=int(_os.environ.get('SIMON','1'))
SIMMIN=float(_os.environ.get('SIMMIN','0.5'))
SIMBUDGET=float(_os.environ.get('SIMBUDGET','0.06'))
KILL_TABLE = [{"('Steg', 1, '..O', 1, 2)": 0.08940520446096654, "('Steg', 2, '.O', 2, 1)": 0.06525, "('Steg', 2, '.O', 1, 1)": 0.037142857142857144, "('Steg', 2, '..O', 1, 1)": 0.05394321766561515, "('Steg', 2, '..', 0, 1)": 0.006461538461538462, "('Steg', 2, '.W', 1, 1)": 0.0020408163265306124, "('Steg', 1, 'OOW', 2, 2)": 0.23461538461538461, "('Steg', 1, '...', 0, 2)": 0.027931034482758618, "('Steg', 2, '...', 0, 1)": 0.007216494845360825, "('Steg', 1, '...', 1, 2)": 0.04008810572687224, "('Steg', 2, '...', 1, 1)": 0.004680851063829788, "('Steg', 0, 'OOOO', 4, 3)": 0.2625, "('Steg', 1, '..O', 2, 2)": 0.10891364902506964, "('Steg', 2, '..O', 2, 1)": 0.08925925925925926, "('Steg', 0, '...O', 1, 3)": 0.09804878048780488, "('Steg', 2, '.O', 3, 1)": 0.06853932584269662, "('Steg', 1, 'OOO', 3, 2)": 0.18363636363636363, "('Steg', 2, 'OOW', 3, 1)": 0.22142857142857145, "('Steg', 1, '.OO', 2, 2)": 0.1334470989761092, "('Steg', 2, '..', 1, 1)": 0.006768558951965066, "('Steg', 1, '.OW', 1, 2)": 0.21607142857142855, "('Steg', 0, '....', 0, 3)": 0.056164383561643834, "('Steg', 1, '.WW', 1, 2)": 0.009090909090909092, "('Steg', 0, '..OO', 2, 3)": 0.11105263157894738, "('Steg', 2, 'OO', 3, 1)": 0.17619047619047618, "('Steg', 2, 'OOW', 2, 1)": 0.13125, "('Steg', 2, '.OO', 2, 1)": 0.11353383458646617, "('Steg', 1, '..W', 0, 2)": 0.03793103448275863, "('Steg', 2, 'OW', 2, 1)": 0.18205128205128204, "('Steg', 2, '.OW', 2, 1)": 0.10512820512820512, "('Steg', 2, '.OO', 3, 1)": 0.11098901098901098, "('Steg', 0, '.OOO', 3, 3)": 0.18958333333333333, "('Steg', 1, '.OW', 2, 2)": 0.10512820512820512, "('Steg', 1, 'OOW', 3, 2)": 0.18636363636363634, "('Steg', 0, '..OW', 1, 3)": 0.075, "('Steg', 1, 'OOO', 4, 2)": 0.132258064516129, "('Steg', 2, 'OO', 4, 1)": 0.11666666666666667, "('Steg', 2, '..W', 1, 1)": 0.040740740740740744, "('Steg', 0, 'OOOW', 3, 3)": 0.15714285714285717, "('Steg', 2, '..', 2, 1)": 0.01707317073170732, "('Steg', 2, '.OW', 1, 1)": 0.002564102564102564, "('Velo', 1, '..O', 1, 2)": 0.26708860759493674, "('Velo', 2, '..', 1, 1)": 0.001639344262295082, "('Velo', 0, '..OW', 1, 3)": 0.15714285714285717, "('Velo', 1, '...', 1, 2)": 0.044000000000000004, "('Steg', 2, '.W', 0, 1)": 0.1576923076923077, "('Velo', 1, '.WW', 0, 2)": 0.23846153846153847, "('Steg', 2, 'OWW', 2, 1)": 0.0125, "('Steg', 1, '.OO', 3, 2)": 0.18859060402684566, "('Steg', 2, '.W', 2, 1)": 0.006666666666666667, "('Velo', 2, '..O', 1, 1)": 0.3258064516129032, "('Velo', 2, '.OW', 1, 1)": 0.3875, "('Steg', 2, 'OOO', 4, 1)": 0.3, "('Velo', 2, '.O', 1, 1)": 0.43913043478260866, "('Velo', 2, '...', 0, 1)": 0.02441860465116279, "('Tric', 2, '..O', 1, 1)": 0.2046875, "('Tric', 2, '.O', 2, 1)": 0.16944444444444443, "('Tric', 1, '.OO', 2, 2)": 0.11923076923076924, "('Tric', 0, '..OO', 2, 3)": 0.155, "('Tric', 1, '...', 1, 2)": 0.02619047619047619, "('Tric', 2, '.O', 1, 1)": 0.2927272727272728, "('Tric', 2, '..W', 0, 1)": 0.3416666666666666, "('Tric', 1, '...', 0, 2)": 0.04492753623188406, "('Tric', 1, 'OWW', 1, 2)": 0.18333333333333335, "('Tric', 1, '..W', 0, 2)": 0.15, "('Tric', 2, '..', 0, 1)": 0.08840579710144927, "('Velo', 1, '...', 0, 2)": 0.046363636363636364, "('Tric', 1, '.OW', 1, 2)": 0.1159090909090909, "('Tric', 2, '..', 1, 1)": 0.24574468085106385, "('Steg', 2, 'OOO', 3, 1)": 0.08461538461538462, "('Velo', 2, '..W', 0, 1)": 0.08157894736842106, "('Velo', 1, '..W', 0, 2)": 0.09999999999999999, "('Tric', 0, '..OW', 1, 3)": 0.24285714285714283, "('Tric', 2, '.W', 1, 1)": 0.061764705882352944, "('Tric', 1, '..O', 1, 2)": 0.07398373983739837, "('Tric', 2, '.OO', 2, 1)": 0.3727272727272727, "('Tric', 1, 'OOW', 2, 2)": 0.2625, "('Tric', 2, '.O', 3, 1)": 0.35000000000000003, "('Tric', 0, '...O', 1, 3)": 0.16511627906976745, "('Tric', 2, '.OW', 2, 1)": 0.41, "('Tric', 2, '..O', 2, 1)": 0.2318181818181818, "('Velo', 0, '....', 0, 3)": 0.1105263157894737, "('Tric', 1, '..O', 2, 2)": 0.05675675675675676, "('Velo', 2, '.O', 2, 1)": 0.425, "('Velo', 2, '.OO', 2, 1)": 0.5166666666666667, "('Steg', 0, 'OOWW', 2, 3)": 0.3875, "('Steg', 2, 'OW', 1, 1)": 0.19090909090909092, "('Velo', 2, '..', 0, 1)": 0.03229166666666667, "('Steg', 0, '.OOW', 2, 3)": 0.355, "('Velo', 1, '.OO', 2, 2)": 0.007692307692307693, "('Tric', 2, 'OO', 3, 1)": 0.41, "('Steg', 1, '..W', 1, 2)": 0.05500000000000001, "('Tric', 1, '.OW', 2, 2)": 0.005555555555555556, "('Velo', 0, '..OO', 2, 3)": 0.41764705882352937, "('Velo', 1, '..O', 2, 2)": 0.33888888888888885, "('Velo', 2, '..O', 2, 1)": 0.1, "('Tric', 2, '.OW', 1, 1)": 0.2217391304347826, "('Velo', 2, '..W', 1, 1)": 0.011111111111111112, "('Velo', 0, '...O', 1, 3)": 0.17222222222222222, "('Steg', 2, 'OO', 2, 1)": 0.13653846153846153, "('Tric', 0, '.OOW', 2, 3)": 0.5166666666666667, "('Tyra', 2, '...', 0, 1)": 0.002777777777777778, "('Steg', 2, '..W', 0, 1)": 0.07777777777777778, "('Velo', 0, '..WW', 0, 3)": 0.3875, "('Velo', 2, '.W', 0, 1)": 0.19375, "('Steg', 2, '.WW', 0, 1)": 0.35000000000000003, "('Tric', 2, '..W', 1, 1)": 0.17222222222222222, "('Velo', 0, '...W', 0, 3)": 0.006666666666666667, "('Tric', 2, '...', 0, 1)": 0.06949152542372881, "('Tric', 2, '.W', 0, 1)": 0.17500000000000002, "('Tric', 0, '....', 0, 3)": 0.22777777777777775, "('Tyra', 2, '..', 0, 1)": 0.002631578947368421, "('Tric', 2, '...', 1, 1)": 0.30606060606060603, "('Velo', 2, '...', 1, 1)": 0.04583333333333334, "('Tyra', 1, '...', 0, 2)": 0.03620689655172414, "('Tric', 1, '.WW', 0, 2)": 0.0125, "('Tric', 2, 'OW', 2, 1)": 0.18333333333333335, "('Tyra', 0, '....', 0, 3)": 0.014285714285714287, "('Tric', 1, '.OO', 3, 2)": 0.18333333333333335, "('Tyra', 2, '..W', 0, 1)": 0.2625, "('Velo', 2, '.WW', 0, 1)": 0.15714285714285717, "('Tric', 1, '..W', 1, 2)": 0.07777777777777778, "('Tric', 2, '.WW', 1, 1)": 0.3, "('Tric', 2, '.WW', 0, 1)": 0.5857142857142856, "('Tric', 2, '..', 2, 1)": 0.22142857142857145, "('Tric', 2, 'OW', 1, 1)": 0.22142857142857145, "('Velo', 1, '..W', 1, 2)": 0.18333333333333335, "('Velo', 1, '.OW', 1, 2)": 0.3, "('Velo', 2, '..', 2, 1)": 0.0125, "('Tric', 2, 'WW', 1, 3)": 0.85, "('Steg', 0, '.OWW', 1, 3)": 0.35000000000000003, "('Steg', 2, 'OW', 3, 1)": 0.11000000000000001, "('Steg', 2, '.WW', 1, 1)": 0.15714285714285717, "('Steg', 0, '...W', 0, 3)": 0.15714285714285717, "('Tyra', 1, '..W', 0, 2)": 0.014285714285714287}, {"('Steg', 1, '..O', 2)": 0.09720982142857142, "('Steg', 2, '.O', 1)": 0.05614754098360656, "('Steg', 2, '..O', 1)": 0.07013651877133106, "('Steg', 2, '..', 1)": 0.007853982300884955, "('Steg', 2, '.W', 1)": 0.046590909090909086, "('Steg', 1, 'OOW', 2)": 0.2148936170212766, "('Steg', 1, '...', 2)": 0.033139534883720935, "('Steg', 2, '...', 1)": 0.005904761904761905, "('Steg', 0, 'OOOO', 3)": 0.2625, "('Steg', 0, '...O', 3)": 0.09804878048780488, "('Steg', 1, 'OOO', 2)": 0.16588235294117645, "('Steg', 2, 'OOW', 1)": 0.17586206896551723, "('Steg', 1, '.OO', 2)": 0.15215419501133787, "('Steg', 1, '.OW', 2)": 0.17127659574468088, "('Steg', 0, '....', 3)": 0.056164383561643834, "('Steg', 1, '.WW', 2)": 0.007692307692307693, "('Steg', 0, '..OO', 3)": 0.11105263157894738, "('Steg', 2, 'OO', 1)": 0.1534351145038168, "('Steg', 2, '.OO', 1)": 0.1125560538116592, "('Steg', 1, '..W', 2)": 0.043750000000000004, "('Steg', 2, 'OW', 1)": 0.17413793103448275, "('Steg', 2, '.OW', 1)": 0.053246753246753244, "('Steg', 0, '.OOO', 3)": 0.18958333333333333, "('Steg', 2, 'WW', 3)": 0.8999999999999999, "('Steg', 0, '..OW', 3)": 0.075, "('Steg', 2, '..W', 1)": 0.05849056603773585, "('Steg', 0, 'OOOW', 3)": 0.15714285714285717, "('Velo', 1, '..O', 2)": 0.28229166666666666, "('Velo', 2, '..', 1)": 0.01901840490797546, "('Velo', 0, '..OW', 3)": 0.15714285714285717, "('Velo', 1, '...', 2)": 0.04552238805970149, "('Velo', 1, '.WW', 2)": 0.22142857142857145, "('Steg', 2, 'OWW', 1)": 0.09166666666666667, "('Velo', 2, '..O', 1)": 0.2707317073170732, "('Velo', 2, '.OW', 1)": 0.41, "('Steg', 2, 'OOO', 1)": 0.21034482758620687, "('Velo', 2, '.O', 1)": 0.4351351351351352, "('Velo', 2, '...', 1)": 0.028440366972477066, "('Tric', 2, '..O', 1)": 0.21294117647058824, "('Tric', 2, '.O', 1)": 0.2536842105263158, "('Tric', 1, '.OO', 2)": 0.132258064516129, "('Tric', 0, '..OO', 3)": 0.155, "('Tric', 1, '...', 2)": 0.03727272727272727, "('Tric', 2, '..W', 1)": 0.24482758620689654, "('Tric', 1, 'OWW', 2)": 0.18333333333333335, "('Tric', 1, '..W', 2)": 0.1025, "('Tric', 2, '..', 1)": 0.18342857142857144, "('Tric', 1, '.OW', 2)": 0.08360655737704917, "('Velo', 2, '..W', 1)": 0.06739130434782609, "('Velo', 1, '..W', 2)": 0.1108695652173913, "('Tric', 0, '..OW', 3)": 0.24285714285714283, "('Tric', 2, '.OO', 1)": 0.4066666666666666, "('Tric', 2, '.W', 1)": 0.12708333333333333, "('Tric', 1, '..O', 2)": 0.06981132075471698, "('Tric', 1, 'OOW', 2)": 0.23333333333333334, "('Tric', 0, '...O', 3)": 0.16511627906976745, "('Tric', 2, '.OW', 1)": 0.284375, "('Velo', 0, '....', 3)": 0.1105263157894737, "('Velo', 2, '.OO', 1)": 0.3875, "('Steg', 0, 'OOWW', 3)": 0.3875, "('Steg', 0, '.OOW', 3)": 0.355, "('Velo', 1, '.OO', 2)": 0.06875, "('Tric', 2, 'OO', 1)": 0.3923076923076923, "('Velo', 0, '..OO', 3)": 0.41764705882352937, "('Velo', 0, '...O', 3)": 0.17222222222222222, "('Tric', 0, '.OOW', 3)": 0.5166666666666667, "('Tyra', 2, '...', 1)": 0.002777777777777778, "('Velo', 0, '..WW', 3)": 0.3875, "('Velo', 2, '.W', 1)": 0.17222222222222222, "('Steg', 2, '.WW', 1)": 0.25833333333333336, "('Velo', 0, '...W', 3)": 0.006666666666666667, "('Tric', 2, '...', 1)": 0.15494505494505495, "('Tric', 0, '....', 3)": 0.22777777777777775, "('Tyra', 2, '..', 1)": 0.0024390243902439024, "('Tyra', 1, '...', 2)": 0.03620689655172414, "('Tric', 1, '.WW', 2)": 0.01, "('Tyra', 2, '.W', 1)": 0.4428571428571429, "('Tric', 2, 'OW', 1)": 0.2157894736842105, "('Tyra', 0, '....', 3)": 0.014285714285714287, "('Tyra', 2, '..W', 1)": 0.31, "('Steg', 1, 'OWW', 2)": 0.014285714285714287, "('Velo', 2, '.WW', 1)": 0.15714285714285717, "('Tric', 2, '.WW', 1)": 0.46923076923076923, "('Velo', 1, '.OW', 2)": 0.3, "('Tric', 2, 'WW', 3)": 0.8714285714285713, "('Steg', 0, '.OWW', 3)": 0.35000000000000003, "('Tyra', 1, '..W', 2)": 0.12222222222222223, "('Steg', 0, '...W', 3)": 0.15714285714285717, "('Tyra', 1, '..O', 2)": 0.18333333333333335}, {"('Steg', 1, 2)": 0.09962599345488546, "('Steg', 2, 1)": 0.05023215322112594, "('Steg', 0, 3)": 0.12179054054054053, "('Steg', 2, 3)": 0.9307692307692308, "('Velo', 2, 1)": 0.12267573696145125, "('Velo', 1, 2)": 0.14681528662420382, "('Velo', 0, 3)": 0.19634146341463415, "('Tric', 2, 1)": 0.21876019575856442, "('Tric', 1, 2)": 0.07825059101654847, "('Tric', 0, 3)": 0.22894736842105265, "('Tyra', 2, 1)": 0.06703296703296703, "('Tyra', 1, 2)": 0.05466666666666666, "('Tyra', 0, 3)": 0.011111111111111112, "('Tric', 2, 3)": 0.8714285714285713}]
import os
ESC=float(os.environ.get('ESC','0.05'))
YW=float(os.environ.get('YW','3'))
KESC=int(os.environ.get('KESC','3'))
POCC=float(os.environ.get('POCC','0.4'))
PRED=int(os.environ.get('PRED','1'))
VFIRST=int(os.environ.get('VFIRST','1'))
MINK=float(os.environ.get('MINK','0'))
BLOCK=int(os.environ.get('BLOCK','1'))  # secondes par tour (le serveur coupe à ~150 ms)


class Strategy:
    def __init__(self):
        self.hist = {}

    def next_pos(self, d):
        h = self.hist.get(d.id, [])
        x, y = d.position.x, d.position.y
        if PRED and len(h) >= 2:
            nx, ny = x + h[-1][0] - h[-2][0], y + h[-1][1] - h[-2][1]
            if self.walkable(nx, ny):
                return nx, ny
        return x, y

    def decide(self, s: TeamGameState):
        self.t0 = time.perf_counter()
        alive = set()
        for d in s.dinosaurs:
            alive.add(d.id)
            h = self.hist.setdefault(d.id, [])
            h.append((d.position.x, d.position.y))
            del h[:-3]
        self.hist = {k: v for k, v in self.hist.items() if k in alive}
        c = s.constants
        self.delay = c.meteorDelay
        self.radius = c.meteorRadius
        self.shift = c.mapShiftInterval or 5
        self.tick = s.currentTick
        m = s.map
        self.ox, self.oy = m.origin.x, m.origin.y
        self.W, self.H = m.width, m.height
        self.tiles = m.tiles
        self.occupied = {(d.position.x, d.position.y) for d in s.dinosaurs}

        # Cases déjà condamnées par une météorite en vol
        doomed = {(p.x, p.y) for met in s.meteors for p in met.impactedTiles}

        # Dinos qui seront sortis du cadre avant l'impact : ils meurent seuls
        impact_tick = self.tick + self.delay
        oy_at_impact = self.oy + (impact_tick // self.shift - self.tick // self.shift)

        targets = [
            d for d in s.dinosaurs
            if (d.position.x, d.position.y) not in doomed
            and d.position.y >= oy_at_impact
        ]
        if not targets:
            return []

        if VFIRST and len(s.volcanoes) < c.maxVolcanoes and s.mountains:
            v = self.best_volcano_reach(s)
            if v is not None:
                return [TriggerVolcanoAction(target=WorldPosition(x=v[0], y=v[1]))]

        # 1) Météorite : simulation exacte des fuites
        if len(s.meteors) < c.maxMeteors and SIMON:
            best = self.sim_meteor(s)
            if best is not None:
                return [LaunchMeteorAction(target=WorldPosition(x=best[0], y=best[1]))]

        if len(s.meteors) < c.maxMeteors:
            best = self.best_meteor(targets, oy_at_impact)
            if best is not None:
                return [LaunchMeteorAction(target=WorldPosition(x=best[0], y=best[1]))]

        # 2) Sinon volcan (une seule action par tour)
        if len(s.volcanoes) < c.maxVolcanoes and s.mountains:
            v = self.best_volcano(targets, s)
            if v is not None:
                return [TriggerVolcanoAction(target=WorldPosition(x=v[0], y=v[1]))]
        return []

    # ------------------------------------------------------------------ outils
    def out_of_time(self):
        return time.perf_counter() - self.t0 > TIME_BUDGET

    def tile(self, x, y):
        i, j = y - self.oy, x - self.ox
        if 0 <= i < self.H and 0 <= j < self.W:
            return self.tiles[i][j]
        return None

    def in_frame(self, x, y, oy=None):
        oy = self.oy if oy is None else oy
        return self.ox <= x < self.ox + self.W and oy <= y < oy + self.H

    def walkable(self, x, y):
        t = self.tile(x, y)
        return t is not None and not t.isImpassable and not t.hasLava

    @staticmethod
    def value(age_at_impact):
        # Décroissance rapide puis lente (forme exacte inconnue)
        return 1.0 / (1.0 + 0.5 * age_at_impact)

    # --------------------------------------------------------------- météorite
    def in_blast(self, cx, cy, x, y):
        return abs(cx - x) + abs(cy - y) <= self.radius

    def escape_steps(self, x0, y0, cx, cy, useocc=False):
        """Pas minimum pour qu'un dino en (x0,y0) sorte de la zone centrée (cx,cy)."""
        seen = {(x0, y0)}
        frontier = [(x0, y0)]
        steps = 0
        while frontier and steps < 5:
            steps += 1
            nxt = []
            for x, y in frontier:
                for q in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                    if q in seen or not self.walkable(*q) or (useocc and q in self.occupied):
                        continue
                    if not self.in_blast(cx, cy, *q):
                        return steps
                    seen.add(q)
                    nxt.append(q)
            frontier = nxt
        return 5  # piégé

    def feats(self, x, y, cx, cy):
        d0 = abs(x - cx) + abs(y - cy)
        f = []
        nocc = 0
        for mx, my in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            q = (x + mx, y + my)
            if q in self.occupied:
                nocc += 1
            if abs(q[0] - cx) + abs(q[1] - cy) > d0:
                f.append('W' if not self.walkable(*q) else ('O' if q in self.occupied else '.'))
        return ''.join(sorted(f)), nocc

    def kill_prob(self, d, cx, cy, cache):
        x, y = d.position.x, d.position.y
        if not self.in_blast(cx, cy, x, y):
            return 0.0
        key = (d.id, cx, cy)
        if key not in cache:
            g = d.name[:4]
            dd = abs(x - cx) + abs(y - cy)
            e = self.escape_steps(x, y, cx, cy)
            f, nocc = self.feats(x, y, cx, cy)
            p = None
            for i, k in enumerate(((g, dd, f, nocc, e), (g, dd, f, e), (g, dd, e))):
                p = KILL_TABLE[i].get(str(k))
                if p is not None:
                    break
            if p is None:
                p = 1.0 if e >= 4 else 0.1
            cache[key] = p
        return cache[key]

    def best_meteor(self, targets, oy_at_impact):
        r = self.radius
        # Les plus jeunes d'abord : si le temps manque, on a traité les meilleurs
        targets = sorted(targets, key=lambda d: d.age)
        cands = []
        seen = set()
        for d in targets:
            for dx in range(-r, r + 1):
                for dy in range(-(r - abs(dx)), r - abs(dx) + 1):
                    c = (d.position.x + dx, d.position.y + dy)
                    if c not in seen and self.in_frame(*c):
                        seen.add(c)
                        cands.append(c)

        cache = {}
        best, best_score = None, 0.0
        for cx, cy in cands:
            if self.out_of_time():
                break
            kills, score = 0.0, 0.0
            for d in targets:
                p = self.kill_prob(d, cx, cy, cache)
                if p:
                    kills += p
                    score += p * self.value(d.age + self.delay)
            if kills >= 1.5:
                score *= 1 + 0.5 * (kills - 1)
            if kills >= MINK and score > best_score:
                best, best_score = (cx, cy), score
        return best

    def sim_meteor(self, s):
        world = World(s)
        T = s.currentTick
        dinos = [(d.id, (d.position.x, d.position.y), d.age, d.name) for d in s.dinosaurs]
        mets = [((m.target.x, m.target.y), m.turnsUntilImpact,
                 {(p.x, p.y) for p in m.impactedTiles}, -1) for m in s.meteors]
        horizon = world.delay + 1
        base = Sim(world, T, dinos, mets).run(horizon)
        cnt = {}
        for _, (x, y), age, _ in dinos:
            for c in world.blast((x, y)):
                if world.in_frame(c, world.oy):
                    cnt[c] = cnt.get(c, 0) + 1
        cands = sorted(cnt, key=lambda c: -cnt[c])
        best, best_gain = None, SIMMIN
        self.nsim = 0
        for c in cands:
            if time.perf_counter() - self.t0 > SIMBUDGET:
                break
            tiles = {p for p in world.blast(c) if world.in_frame(p, world.oy)}
            sim = Sim(world, T, dinos, mets + [(c, world.delay, tiles, T + 1)])
            gain = sim.run(horizon) - base
            self.nsim += 1
            if gain > best_gain:
                best, best_gain = c, gain
        return best

    # ------------------------------------------------------------------ volcan
    def simulate_lava(self, sx, sy, ticks=10):
        lava = {(sx, sy)}
        frontier = [(sx, sy)]
        for _ in range(ticks):
            nxt = []
            for x, y in frontier:
                here = self.tile(x, y)
                h = here.elevation if here else 0
                neigh = []
                for q in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                    t = self.tile(*q)
                    if t is None or t.isImpassable or q in lava or t.elevation > h:
                        continue
                    neigh.append((t.elevation, q))
                if not neigh:
                    continue
                low = min(e for e, _ in neigh)
                for e, q in neigh:
                    if e == low and q not in lava:
                        lava.add(q)
                        nxt.append(q)
            frontier = nxt
            if not frontier:
                break
        return lava

    def reach(self, sx, sy):
        """Cases que la lave finira par couvrir : chemins à pente descendante ou plate."""
        src = self.tile(sx, sy)
        seen = {(sx, sy)}
        stack = [(sx, sy, src.elevation)]
        while stack:
            x, y, h = stack.pop()
            for q in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if q in seen:
                    continue
                t = self.tile(*q)
                if t is None or t.isImpassable or t.elevation > h:
                    continue
                seen.add(q)
                stack.append((q[0], q[1], t.elevation))
        return seen

    def best_volcano_reach(self, s):
        active = {(v.position.x, v.position.y) for v in s.volcanoes}
        best, best_score = None, -1
        for mpos in s.mountains:
            m = (mpos.x, mpos.y)
            if m in active or not self.in_frame(*m):
                continue
            r = self.reach(*m)
            new = sum(1 for p in r if not self.tile(*p).hasLava)
            score = new + YW * (m[1] - self.oy)
            if score > best_score:
                best, best_score = m, score
        return best

    def best_volcano(self, targets, s):
        active = {(v.position.x, v.position.y) for v in s.volcanoes}
        best, best_score = None, 0.0
        for mpos in s.mountains:
            if self.out_of_time():
                break
            m = (mpos.x, mpos.y)
            if m in active or not self.in_frame(*m):
                continue
            lava = self.simulate_lava(*m)
            score = 0.0
            for d in targets:
                x, y = d.position.x, d.position.y
                if any((x + a, y + b) in lava for a, b in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1))):
                    score += self.value(d.age + 2)
            if score > best_score:
                best, best_score = m, score
        return best
