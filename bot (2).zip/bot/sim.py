"""Simulation fidèle (simplifiée) des règles du moteur pour prédire les fuites.

Reproduit : zone de danger, temps avant danger (Ne), distance à la sécurité (zn),
logique de fuite commune (Sr / ro), déplacement normal des stégosaures,
impacts, sortie de cadre et points (decay exact).
"""
import math

INF = float("inf")
DIRS = ((1, 0), (-1, 0), (0, 1), (0, -1))


def decay(age):
    return math.ceil(max(0.0, 500 / math.sqrt(age / 4 + 5) - 60))


class World:
    """Données statiques du tour (carte)."""

    def __init__(self, s):
        m = s.map
        self.ox, self.oy, self.W, self.H = m.origin.x, m.origin.y, m.width, m.height
        self.elev = {}
        self.imp = set()
        self.lava = set()
        self.mount = set()
        for row in m.tiles:
            for t in row:
                p = (t.position.x, t.position.y)
                self.elev[p] = t.elevation
                if t.isImpassable:
                    self.imp.add(p)
                if t.hasLava:
                    self.lava.add(p)
                if t.isMountain:
                    self.mount.add(p)
        self.radius = s.constants.meteorRadius
        self.delay = s.constants.meteorDelay
        self.shift = s.constants.mapShiftInterval
        # danger statique : lave, infranchissable, voisins pouvant recevoir lave
        st = set(self.lava) | set(self.imp)
        for p in self.lava | self.mount:
            h = self.elev[p]
            for dx, dy in DIRS:
                q = (p[0] + dx, p[1] + dy)
                if q in self.elev and q not in self.imp and q not in self.lava and self.elev[q] <= h:
                    st.add(q)
        self.static_danger = st
        self._xr_cache = {}

    def in_frame(self, p, oy):
        return self.ox <= p[0] < self.ox + self.W and oy <= p[1] < oy + self.H and p in self.elev

    def blast(self, c):
        r = self.radius
        out = []
        for i in range(-r, r + 1):
            for j in range(-r, r + 1):
                if i * i + j * j <= r * r:
                    out.append((c[0] + i, c[1] + j))
        return out

    def xr(self, target, oy):
        """BFS depuis la cible sur cases franchissables sans lave."""
        key = (target, oy)
        if key in self._xr_cache:
            return self._xr_cache[key]
        dist = {}
        fr = []
        if self.in_frame(target, oy):
            dist[target] = 0
            fr = [target]
        else:
            for dx, dy in DIRS:
                q = (target[0] + dx, target[1] + dy)
                if self.in_frame(q, oy) and q not in self.imp and q not in self.lava:
                    dist[q] = 1
                    fr.append(q)
        i = 0
        while i < len(fr):
            p = fr[i]
            i += 1
            d = dist[p] + 1
            for dx, dy in DIRS:
                q = (p[0] + dx, p[1] + dy)
                if q in dist or not self.in_frame(q, oy) or q in self.imp or q in self.lava:
                    continue
                dist[q] = d
                fr.append(q)
        self._xr_cache[key] = dist
        return dist

    def steg_target(self, turn, oy):
        r = oy + (2 * self.H) // 3
        n = max(1, 2 * (self.W - 1))
        i = turn % n
        o = i if i < self.W else n - i
        return (self.ox + o, r)


class Sim:
    def __init__(self, world, turn, dinos, meteors):
        """dinos: liste de [id, (x,y), age, name]; meteors: liste de [target, tui, tiles(set), launched]"""
        self.w = world
        self.turn = turn  # dernier tour joué (état reçu)
        self.oy = world.oy
        self.dinos = [list(d) for d in dinos]
        self.meteors = [list(m) for m in meteors]
        self.score = 0.0
        self.kills = 0

    # --- danger -------------------------------------------------------
    def build_danger(self):
        w = self.w
        danger = set(w.static_danger)
        ne = {}
        targets = []
        for tgt, tui, tiles, _ in self.meteors:
            targets.append(tgt)
            for p in tiles:
                danger.add(p)
                if ne.get(p, INF) > tui:
                    ne[p] = tui
        for p in w.lava:
            ne[p] = 0
            targets.append(p)
        self.danger = danger
        self.ne = ne
        self.targets = targets
        # distance à la sécurité (BFS multi-source depuis les cases sûres)
        oy = self.oy
        zn = {}
        fr = []
        for p in w.elev:
            if p[1] < oy:
                continue
            if p in w.imp or p in danger:
                continue
            zn[p] = 0
            fr.append(p)
        i = 0
        while i < len(fr):
            p = fr[i]
            i += 1
            d = zn[p] + 1
            for dx, dy in DIRS:
                q = (p[0] + dx, p[1] + dy)
                if q in zn or q not in w.elev or q[1] < oy or q in w.imp:
                    continue
                zn[q] = d
                fr.append(q)
        self.zn = zn

    def Ne(self, p):
        return self.ne.get(p, INF)

    def znf(self, p):
        if p not in self.danger:
            return 0
        return self.zn.get(p, INF)

    def bt(self, p, turn):
        oy = self.oy + (1 if (turn > 0 and turn % self.w.shift == 0) else 0)
        return self.w.in_frame(p, oy) if p[1] >= oy else False

    def neighbors(self, p):
        out = []
        for dx, dy in DIRS:
            q = (p[0] + dx, p[1] + dy)
            if self.w.in_frame(q, self.oy):
                out.append(q)
        return out

    def Wt(self, cands, turn):
        if not cands:
            return cands
        r = [q for q in cands if self.bt(q, turn)]
        n = r if r else cands
        o = [q for q in n if q not in self.danger]
        return o if o else n

    def Sr(self, pos, cands, turn):
        i = list(cands)
        if self.bt(pos, turn) and self.Ne(pos) == INF:
            i.append(pos)
        if not i:
            return pos
        best = max(self.Ne(q) for q in i)
        a = [q for q in i if self.Ne(q) == best]
        if best != INF:
            mz = min(self.znf(q) for q in a)
            a = [q for q in a if self.znf(q) == mz]
        if len(a) > 1 and self.targets:
            def sc(q):
                return min(math.hypot(q[0] - t[0], q[1] - t[1]) for t in self.targets)
            mx = max(sc(q) for q in a)
            a = [q for q in a if sc(q) == mx]
        return a[0]

    def ro(self, pos, cands, turn):
        if not cands:
            return None
        if self.Ne(pos) != INF:
            return self.Sr(pos, cands, turn)
        nsafe = 0
        for q in self.neighbors(pos):
            if q not in self.w.imp and q not in self.danger:
                nsafe += 1
        if nsafe < 2:
            return self.Sr(pos, cands, turn)
        return None

    def decide(self, d, turn):
        pos = d[1]
        name = d[3]
        r = self.Wt(self.neighbors(pos), turn)
        if name == "Stegosaurus":
            if not r:
                return pos
            n = self.ro(pos, r, turn)
            if n is not None:
                return n
            tgt = self.w.steg_target(turn, self.oy)
            dist = self.w.xr(tgt, self.oy)
            if pos == tgt:
                dist = self.w.xr(self.w.steg_target(turn + 1, self.oy), self.oy)
            bestd = min(dist.get(q, INF) for q in r)
            if bestd == INF:
                return self.Sr(pos, r, turn)
            for q in r:
                if dist.get(q, INF) == bestd:
                    return q
        # autres espèces : fuite si danger, sinon immobile (approximation)
        if self.Ne(pos) != INF:
            return self.Sr(pos, r, turn)
        if name == "Triceratops":
            n = self.ro(pos, r, turn)
            if n is not None:
                return n
        return pos

    # --- un tour ------------------------------------------------------
    def step(self):
        w = self.w
        self.turn += 1
        turn = self.turn
        # décrément
        for m in self.meteors:
            if m[3] != turn:
                m[1] -= 1
        # impacts
        tick_scores = []
        hit = [m for m in self.meteors if m[1] <= 0]
        if hit:
            self.meteors = [m for m in self.meteors if m[1] > 0]
            tiles = set()
            for m in hit:
                tiles |= m[2]
            alive = []
            for d in self.dinos:
                if d[1] in tiles:
                    tick_scores.append(decay(d[2] + 1))
                else:
                    alive.append(d)
            self.dinos = alive
        self.build_danger()
        # déplacements
        intents = {}
        for d in self.dinos:
            q = self.decide(d, turn)
            if q != d[1] and (q in w.imp or not w.in_frame(q, self.oy)):
                q = d[1]
            intents[d[0]] = q
        occ = {d[1]: d[0] for d in self.dinos}
        moved = {}
        stay = set()
        changed = True
        # résolution simple des conflits
        for d in self.dinos:
            if intents[d[0]] == d[1]:
                stay.add(d[0])
        while changed:
            changed = False
            taken = {}
            for d in self.dinos:
                if d[0] in stay:
                    continue
                q = intents[d[0]]
                blocker = occ.get(q)
                if blocker is not None and blocker in stay:
                    stay.add(d[0])
                    changed = True
                    continue
                if q in taken:
                    stay.add(d[0])
                    changed = True
                    continue
                taken[q] = d[0]
        for d in self.dinos:
            if d[0] not in stay:
                d[1] = intents[d[0]]
            d[2] += 1
        # lave immédiate
        alive = []
        for d in self.dinos:
            if d[1] in w.lava:
                tick_scores.append(decay(d[2]))
            else:
                alive.append(d)
        self.dinos = alive
        # défilement
        if turn > 0 and turn % w.shift == 0:
            self.oy += 1
            alive = []
            for d in self.dinos:
                if d[1][1] < self.oy:
                    tick_scores.append(decay(d[2]))
                else:
                    alive.append(d)
            self.dinos = alive
        k = len(tick_scores)
        if k:
            self.score += sum(tick_scores) * (1 + 0.5 * (k - 1))
            self.kills += k

    def run(self, nturns):
        for _ in range(nturns):
            self.step()
        return self.score
